#!/bin/bash
# smart_update.sh - Intelligent pipeline update with full preservation

set -e

echo "=== SMART PODCAST PIPELINE UPDATE ==="
echo ""

# Check location
if [ ! -f "podcast_pipeline.py" ]; then
    echo "❌ ERROR: Run this from your myfirstpodcast_v3 folder"
    exit 1
fi

# Create backup directory
BACKUP_DIR=".update_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "📦 BACKING UP YOUR DATA..."
echo ""

# 1. Backup configs
echo "  → API keys & voice IDs..."
cp config/.env "$BACKUP_DIR/.env" 2>/dev/null || echo "    (No .env found)"
cp config/podcast_config.json "$BACKUP_DIR/podcast_config.json"

# 2. Backup research templates
if [ -d "templates/research_contexts" ]; then
    echo "  → Research context templates..."
    mkdir -p "$BACKUP_DIR/research_contexts"
    cp -r templates/research_contexts/* "$BACKUP_DIR/research_contexts/" 2>/dev/null || true
fi

# 3. Backup all template files
echo "  → Podcast templates..."
mkdir -p "$BACKUP_DIR/templates"
cp templates/*.txt "$BACKUP_DIR/templates/" 2>/dev/null || true

# 4. Backup project contexts
echo "  → Project-specific research contexts..."
mkdir -p "$BACKUP_DIR/project_contexts"
for project_dir in projects/*/; do
    if [ -d "$project_dir" ]; then
        project_name=$(basename "$project_dir")
        if [ -f "$project_dir/sources/research_context.txt" ]; then
            mkdir -p "$BACKUP_DIR/project_contexts/$project_name"
            cp "$project_dir/sources/research_context.txt" "$BACKUP_DIR/project_contexts/$project_name/"
            echo "    ✓ Backed up: $project_name/research_context.txt"
        fi
    fi
done

echo ""
echo "✓ All data backed up to: $BACKUP_DIR"
echo ""

# 5. Update files
echo "📥 UPDATING FILES..."
echo ""

# Handle pipeline files (with or without _FIXED/_new suffix)
if [ -f "podcast_pipeline_FIXED.py" ]; then
    echo "  → Found podcast_pipeline_FIXED.py, installing..."
    OLD_BACKUP="podcast_pipeline_backup_$(date +%Y%m%d_%H%M%S).py"
    mv podcast_pipeline.py "$OLD_BACKUP"
    mv podcast_pipeline_FIXED.py podcast_pipeline.py
    echo "    ✓ Pipeline updated (old: $OLD_BACKUP)"
elif [ -f "podcast_pipeline_new.py" ]; then
    echo "  → Found podcast_pipeline_new.py, installing..."
    OLD_BACKUP="podcast_pipeline_backup_$(date +%Y%m%d_%H%M%S).py"
    mv podcast_pipeline.py "$OLD_BACKUP"
    mv podcast_pipeline_new.py podcast_pipeline.py
    echo "    ✓ Pipeline updated (old: $OLD_BACKUP)"
else
    echo "  ⚠ No new pipeline file (_FIXED.py or _new.py)"
fi

# Handle template files with _FIXED suffix
echo "  → Processing templates..."
for file in *_FIXED.txt; do
    if [ -f "$file" ]; then
        target=$(echo "$file" | sed 's/_FIXED//')
        mv "$file" "templates/$target"
        echo "    ✓ $file → templates/$target"
    fi
done

# Handle loose template files in root
for file in news_brief_*.txt technical_deep_dive_*.txt popular_science_*.txt; do
    if [ -f "$file" ]; then
        mv "$file" "templates/"
        echo "    ✓ $file → templates/"
    fi
done

# Handle config file if in root
if [ -f "podcast_config.json" ]; then
    echo "  → Updating config..."
    mv "podcast_config.json" "config/"
    echo "    ✓ Config moved to config/"
fi

echo ""
echo "📦 RESTORING YOUR DATA..."
echo ""

# 6. Restore configs
echo "  → API keys..."
cp "$BACKUP_DIR/.env" config/.env 2>/dev/null || echo "    (No .env to restore)"
echo "    ✓ Configs restored"

# 7. Restore research templates
if [ -d "$BACKUP_DIR/research_contexts" ]; then
    echo "  → Research templates..."
    mkdir -p templates/research_contexts
    cp -r "$BACKUP_DIR/research_contexts"/* templates/research_contexts/ 2>/dev/null || true
    echo "    ✓ Restored"
fi

# 8. Restore project contexts
echo "  → Project contexts..."
if [ -d "$BACKUP_DIR/project_contexts" ]; then
    for project_dir in "$BACKUP_DIR/project_contexts"/*; do
        if [ -d "$project_dir" ]; then
            project_name=$(basename "$project_dir")
            if [ -f "$project_dir/research_context.txt" ]; then
                mkdir -p "projects/$project_name/sources"
                cp "$project_dir/research_context.txt" "projects/$project_name/sources/"
                echo "    ✓ $project_name/research_context.txt"
            fi
        fi
    done
fi

echo ""
echo "="*60
echo "✅ UPDATE COMPLETE!"
echo "="*60
echo "Backup: $BACKUP_DIR"
echo ""
echo "Preserved:"
echo "  ✓ API keys"
echo "  ✓ Voice config"
echo "  ✓ Templates"
echo "  ✓ Project contexts"
echo ""
echo "Run: python podcast_pipeline.py"
echo ""
