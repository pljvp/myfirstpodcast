# Git Setup

## First Time Setup

```bash
cd myfirstpodcast_v3

# Initialize git (if not already)
git init

# Copy .env.example to .env and add your keys
cp config/.env.example config/.env
nano config/.env
# Add your API keys

# Check what will be committed
git status

# Should NOT see:
# - .env files
# - venv/ folder
# - audio files
# - backup folders

# Add files
git add .

# Commit
git commit -m "Initial commit - v3.1"

# Add remote (replace with your repo URL)
git remote add origin https://github.com/yourusername/podcast-pipeline.git

# Push
git push -u origin main
```

## Daily Workflow

```bash
# Before working
git pull

# After changes
git add .
git commit -m "Description of changes"
git push
```

## Safety Checks

**Always verify .env is not committed:**
```bash
git status | grep .env
# Should return nothing
```

**Check .gitignore is working:**
```bash
# These should be ignored:
ls config/.env          # Your local API keys (safe)
ls venv/                # Virtual environment (ignored)
ls projects/*/audio/    # Audio files (ignored)
```

## Team Collaboration

**New team member setup:**
```bash
# Clone repo
git clone https://github.com/yourusername/podcast-pipeline.git
cd podcast-pipeline

# Create .env from example
cp config/.env.example config/.env
nano config/.env
# Add their API keys

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Ready to use
python podcast_pipeline.py
```

## What's In Git vs Local

**In Git (pushed):**
- ✅ Code (podcast_pipeline.py)
- ✅ Templates
- ✅ Config structure (podcast_config.json)
- ✅ .env.example (template)
- ✅ Documentation
- ✅ .gitignore

**Local Only (not pushed):**
- 🔒 .env (your API keys)
- 🔒 venv/ (virtual environment)
- 🔒 Generated audio files
- 🔒 Backup folders
- 🔒 Project scripts/debug files

## Troubleshooting

**Accidentally committed .env?**
```bash
# Remove from git but keep local file
git rm --cached config/.env
git commit -m "Remove .env from tracking"
git push

# Then regenerate API keys at:
# - https://console.anthropic.com/
# - https://elevenlabs.io/
```

**Want to clean local files?**
```bash
# Remove all ignored files (BE CAREFUL)
git clean -fdX

# Dry run first to see what would be deleted
git clean -ndX
```

Done.
