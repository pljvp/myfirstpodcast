# Install & Git (3 min total)

## 1. Install (30 sec)

```bash
cd myfirstpodcast_v3
# Put all files here, then:
./smart_update.sh
```

Auto-renames _FIXED files, moves everything. Done.

## 2. Git Setup (2 min)

```bash
# Copy git files
cp .gitignore .
cp config_env_example.txt config/.env.example

# Setup .env with your keys
cp config/.env.example config/.env
nano config/.env

# Init & push
git init
git add .
git commit -m "v3.1"
git remote add origin YOUR_REPO_URL
git push -u origin main
```

**.env is safe** - Never pushed (in .gitignore)

## Files (16 total)

1. podcast_pipeline_FIXED.py
2. podcast_config.json
3. smart_update.sh
4-12. Templates (9: 3 styles × DE/EN/NL)
13. .gitignore
14. config_env_example.txt
15. GIT_SETUP.md
16. Docs

## What's Protected

**In .gitignore:**
- config/.env (API keys)
- venv/ (virtual environment)  
- Audio files
- Backups

**Can push safely** ✅

Done.
